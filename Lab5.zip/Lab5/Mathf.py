class Mathf: # A mathf class that implements some of the functions in Mathf from unity
	@staticmethod
	def Clamp(val, _min, _max):
		return max(min(_max, val), _min)
	@staticmethod
	def Lerp(A, B, t):
		return A + (B - A) * Mathf.Clamp(t,0,1)
	@staticmethod
	def LerpUnclamped(A,B,t):
		return A + (B - A) * t